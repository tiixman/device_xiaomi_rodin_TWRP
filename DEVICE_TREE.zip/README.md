#
# Copyright (C) 2025 The Android Open Source Project
#
# SPDX-License-Identifier: Apache-2.0
#
# Android device tree for generic Generic Device (boot)

Generated automatically using TWRP Device Tree Generator
this tool Developed by [Melek Saidani](https://www.facebook.com/no.idea.120/)

Arch: arm64
Manufacturer: generic
Model: Generic Device

